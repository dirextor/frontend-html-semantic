# frontend-html-semantic
Создание документа с использованием только HTML
